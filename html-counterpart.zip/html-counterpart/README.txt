RescuePH Static HTML Counterpart

Open index.html in a browser to view the presentation demo.

Files included:
- index.html (landing page)
- login.html
- dashboard.html
- inventory.html
- donations.html
- relief.html
- evacuation.html
- notifications.html

This version is static and meant for adviser presentation, so it mirrors the UI and navigation of the Laravel app without backend functionality.
